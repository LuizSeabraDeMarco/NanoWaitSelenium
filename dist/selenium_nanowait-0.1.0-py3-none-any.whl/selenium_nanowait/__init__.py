from .wait import wait_for

__all__ = ["wait_for"]
