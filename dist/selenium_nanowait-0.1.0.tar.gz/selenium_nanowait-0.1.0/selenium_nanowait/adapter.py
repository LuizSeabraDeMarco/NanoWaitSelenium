"""
Este arquivo existe para futura integração direta com nano-wait core:
- métricas
- backoff adaptativo
- aprendizado por seletor
"""

# placeholder intencional
